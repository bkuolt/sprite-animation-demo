var searchData=
[
  ['address_533',['address',['../structktxStream.html#ab96816d317aa5196e2ef198d9a8d621b',1,'ktxStream']]],
  ['allocationid_534',['allocationId',['../structktxVulkanTexture.html#a723f84255a60631ba53e0c5d2f8f398f',1,'ktxVulkanTexture']]],
  ['allocatoraddress_535',['allocatorAddress',['../structktxStream.html#a6de39e2650d144d37e3f2c32081dd55f',1,'ktxStream']]],
  ['allocmemfuncptr_536',['allocMemFuncPtr',['../structktxVulkanTexture__subAllocatorCallbacks.html#a2e43825e9413d23c3d6922395071db03',1,'ktxVulkanTexture_subAllocatorCallbacks']]]
];
